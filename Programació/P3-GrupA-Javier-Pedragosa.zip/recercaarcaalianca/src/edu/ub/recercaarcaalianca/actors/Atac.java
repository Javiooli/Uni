package edu.ub.recercaarcaalianca.actors;

import edu.ub.recercaarcaalianca.*;

import java.awt.*;

import java.awt.image.BufferedImage;

public class Atac extends AbstractActor {
    //atributs de la classe
    private String sprite = "slash.png";
    private String sprite2 = "hslash.png";
    private Image[] imatges = new Image[4];
    private final int amplada = 27;
    private final int alcada = 27;
    private final int DURACIO_ATAC = Constants.TEMPS_ENTRE_ATACS;
    private int tempsSenseAtacar = DURACIO_ATAC;
    private Arqueologa arqueologa;
    private int nImg;
    private int direccio;

    public Atac(){
        BufferedImage iTmp = Util.carregarImatge(sprite); 
        imatges[0] = iTmp;
        imatges[1] = Util.flipImatgeVer(iTmp);
        iTmp = Util.carregarImatge(sprite2);
        imatges[2] = iTmp;
        imatges[3] = Util.flipImatgeHor(iTmp);
    }
    public void actualitzar(Context ctx) {
        this.arqueologa = (Arqueologa) ctx.getJoc().getArqueologa();
        if (tempsSenseAtacar < DURACIO_ATAC) tempsSenseAtacar++;
        else {
            this.setPosicio(-250, -250);
            arqueologa.setAtacant(false);
        }
        if (arqueologa.getHasWhip()){
            if (ctx.isKeyPressed(Context.KEY_UP)) {
                direccio = Constants.DIRECCIO_NORD;
                atacar(direccio);
            }
            else if (ctx.isKeyPressed(Context.KEY_DOWN)) {
                direccio = Constants.DIRECCIO_SUD;
                atacar(direccio);
            }
            else if (ctx.isKeyPressed(Context.KEY_LEFT)) {
                direccio = Constants.DIRECCIO_OEST;
                atacar(direccio);
            }
            else if (ctx.isKeyPressed(Context.KEY_RIGHT)) {
                direccio = Constants.DIRECCIO_EST;
                atacar(direccio);
            }
        }
    }
    public Rectangle getLimits() {
        // es important per tractar les colisions des de la classe GuiJoc al metode actualizarJoc
        return new Rectangle(getX(), getY(), amplada, alcada);
    }
    public void tractarColisio(Colisio colisio) {
    }
    
    public void render(Graphics2D g) {
        //Com dibuixar a la pantalla principal
        Image image = imatges[nImg];
        g.drawImage(image, x, y, observer);
    }

    public int getTempsSenseAtacar(){
        return this.tempsSenseAtacar;
    }

    public void setTempsSenseAtacar(int t){
        this.tempsSenseAtacar = t;
    }

    private void atacar(int direccio){
        if (this.tempsSenseAtacar == Constants.TEMPS_ENTRE_ATACS){
            int[] pos = arqueologa.getPosicio();
            tempsSenseAtacar = 0;
            arqueologa.setAtacant(true);
            switch (direccio){
                case (Constants.DIRECCIO_NORD):
                    this.setPosicio(pos[0], pos[1] - 35);
                    this.nImg = 0;
                    break;
                case (Constants.DIRECCIO_SUD):
                    this.setPosicio(pos[0], pos[1] + 60);
                    this.nImg = 1;
                    break;
                case (Constants.DIRECCIO_OEST):
                    this.setPosicio(pos[0] - 40, pos[1]);
                    this.nImg = 2;
                    break;
                case (Constants.DIRECCIO_EST):
                    this.setPosicio(pos[0] + 40, pos[1]);
                    this.nImg = 3;
                    break;
                
            }
        }
    }
}